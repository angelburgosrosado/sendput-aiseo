=== SendPut AI Visibility & MCP Node (SignalForge 3.0) ===
Contributors: sendputai
Tags: ai search, geo, llms.txt, localbusiness schema, mcp, chatgpt search, perplexity
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 3.1.0
License: GPLv2 or later

Make your WordPress business visible to ChatGPT Search, Perplexity, Google Gemini, Claude & Copilot.

== Description ==
SendPut AI Visibility (SignalForge 3.0) is the all-in-one AI Search & Generative Engine Optimization (GEO) plugin for WordPress and Elementor.

**Free Basic Services Included Out of the Box:**
1. **Unblock AI Search Crawlers (`robots.txt`)**: Automatically allows `OAI-SearchBot`, `GPTBot`, `PerplexityBot`, `Claude-SearchBot`, and `Google-Extended`.
2. **Dynamic `/llms.txt` Generator**: Serves a live `/llms.txt` markdown feed at your domain root summarizing your business, hours, services, and top pages.
3. **Validated `LocalBusiness` & `OfferCatalog` JSON-LD**: Injects structured entity schema and bilingual (EN/ES) descriptions in `<head>`.
4. **Business Highlight Shortcodes**: Use `[sendput_ai_badge]` or `[sendput_ai_profile_card]` to highlight your AI-Indexed status.

**Enter a SendPut.com Activation Code (`SP-STARTER-`, `SP-GROWTH-`, `SP-AGENCY-`) to Unlock:**
* Cloud Edge Sync (`/sf-edge.js`) & Public Listing in the **AI-Verified Business Directory** (`https://sendput.com/verified/your-slug`)
* Hosted **Model Context Protocol (MCP) Server** (`/mcp/your-slug/sse`) so AI assistants can quote and book appointments directly
* Automatic **IndexNow** pushes whenever you publish or update a WordPress page or post

== Installation ==
1. Upload `sendput-ai-visibility-wordpress-plugin.zip` via **WordPress Admin -> Plugins -> Add New -> Upload Plugin**.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to **SendPut AI** in your left admin sidebar, enter your Business Profile details (and optional Activation Code from https://sendput.com), and click **Save & Register/Sync Domain with SendPut.com Cloud**.
